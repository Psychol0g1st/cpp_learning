#include <iostream>
#include <fstream>
using namespace std;

#include "megoldott_feladatok.h"

#ifdef PART1
#include "triagecounter.h"
#endif

#ifdef PART2
#include "triagecounter.h"
#endif

#ifdef PART3
#include "triagecounter.h"
#endif

#ifdef PART4
#include "triagecounter.h"
#include "extra.h"
#endif

struct TesterGuard
{
    string partname;
    TesterGuard(const string& partname);
    ~TesterGuard();
};

int main()
{
    cout << "main() eleje!" << endl;

#ifdef PART1
    {
        TesterGuard tguard("PART1");
        TriageCounter<string> tc1;
        TriageCounter<int> tc2;
        tc1.addCase("ICU");
        tc1.addCase("ICU");
        tc1.addCase("LAB");
        tc1.addCase("SURG");
        tc1.addCase("SURG");
        tc2.addCase(1);
        tc2.addCase(1);
        tc2.addCase(3);
        cout << "tc1 teszt:" << endl;
        cout << tc1.getIndexOfTag("ICU") << " ";
        cout << tc1.getIndexOfTag("ER") << " ";
        cout << tc1.getIndexOfTag("SURG") << endl;
        cout << tc1.getCaseCount("ICU") << " ";
        cout << tc1.getCaseCount("ER") << " ";
        cout << tc1.getCaseCount("SURG") << endl;
        cout << "tc2 teszt:" << endl;
        cout << tc2.getIndexOfTag(1) << " ";
        cout << tc2.getIndexOfTag(2) << " ";
        cout << tc2.getIndexOfTag(3) << endl;
        cout << tc2.getCaseCount(1) << " ";
        cout << tc2.getCaseCount(2) << " ";
        cout << tc2.getCaseCount(3) << endl;
    }
#endif

#ifdef PART2
    {
        TesterGuard tguard("PART2");
        TriageCounter<string> tc3;
        tc3["ICU"] = 5;
        tc3.addCase("ICU");
        tc3["LAB"] = 2;
        cout << "Kiiras:" << endl;
        cout << tc3["ICU"] << endl;
        cout << tc3["LAB"] << endl;
        cout << tc3["OBS"] << endl;
    }
#endif

#ifdef PART3
    {
        TesterGuard tguard("PART3");
        TriageCounter<string> tc1;
        tc1.addCase("cardiology");
        tc1.addCase("cardiology");
        tc1.addCase("cardiology");
        tc1.addCase("cardiology");
        tc1.addCase("neurology");
        tc1.addCase("neurology");
        cout << "tc1 kiirasa:" << endl << tc1 << endl;
    }
#endif

#ifdef PART4
    {
        TesterGuard tguard("PART4");
        {
            ofstream out("wards1.txt");
            out << "ICU LAB ICU SURG ICU LAB" << endl;
        }
        {
            ofstream out("wards2.txt");
            out << "ER ER OBS LAB OBS OBS" << endl;
        }
        {
            TriageCounter<string> tc = getWardFrequency("wards1.txt");
            cout << "wards1.txt teszt:" << endl;
            cout << "ICU -> " << tc.getCaseCount("ICU") << endl;
            cout << "LAB -> " << tc.getCaseCount("LAB") << endl;
            cout << "ER -> " << tc.getCaseCount("ER") << endl;
        }
        {
            TriageCounter<string> tc = getWardFrequency("wards2.txt");
            cout << "wards2.txt teszt:" << endl;
            cout << "ER -> " << tc.getCaseCount("ER") << endl;
            cout << "OBS -> " << tc.getCaseCount("OBS") << endl;
            cout << "SURG -> " << tc.getCaseCount("SURG") << endl;
        }
    }
#endif

    cout << "main() vege!" << endl;
    return 0;
}

TesterGuard::TesterGuard(const string& p):
    partname(p)
{
    cout << endl << "----START OF " << partname << "----" << endl << endl;
}

TesterGuard::~TesterGuard()
{
    cout << endl << "----END OF " << partname << "----" << endl << endl;
}
