#ifndef MEGOLDOTT_FELADATOK_H
#define MEGOLDOTT_FELADATOK_H

//#define PART1 // DelayLedger alap (3 pont)
//#define PART2 // DelayLedger, operator[] (2 pont)
//#define PART3 // DelayLedger: JSON kiiras, operator<< (2 pont)
//#define PART4 // extra.h, loadDelays() (3 pont)

#endif // MEGOLDOTT_FELADATOK_H
