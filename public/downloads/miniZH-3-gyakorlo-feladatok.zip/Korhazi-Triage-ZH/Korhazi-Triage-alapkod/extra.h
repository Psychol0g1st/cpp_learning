#ifndef EXTRA_H
#define EXTRA_H

// ide johet a getWardFrequency() fuggveny

#endif // EXTRA_H
