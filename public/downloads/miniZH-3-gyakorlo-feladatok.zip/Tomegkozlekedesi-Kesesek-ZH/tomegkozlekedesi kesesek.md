Tomegkozlekedesi Kesesek KisZH

## 1 / 2

# FONTOS INFOK

- A feladat soran alkalmazd a megtanult objektum-orientaltsagi elveket, figyelj a konstansok es
  referenciak megfelelo hasznalatara.
- A megadott peldakodon ne modosits, hacsak a feladat nem keri.
- Figyelj a kiiras pontos formatumara, szokozokre es sortoresekre.
- Minden pont ertekelesehez szukseges, hogy az adott reszhez tartozo define szerepeljen a
  `megoldott_feladatok.h` fajlban.
- A header fajlokban csak a header guard-on belulre dolgozz.
- Peldakimenet a `main.cpp`-ben es a `minta-stdout.txt` fajlban talalhato.

Tomegkozlekedesi Kesesek KisZH

## 2 / 2

# Feladat - Tomegkozlekedesi Kesesek KisZH

Egy kozlekedesi elemzorendszerhez kell sablon osztalyt kesziteni, amely tetszoleges `T` tipusu
jaratazonositokhoz osszesitett kesesi perceket tarol. Minden a `delayledger.h` fajlba keruljon,
`delayledger.cpp` ne legyen. Az Nlohmann JSON konyvtar a `json.hpp` fajlban adott.

Az elso feladat kotelezo, a 2-4. feladatok egymastol fuggetlenul megoldhatok.

1. Legyen egy `DelayLedger` osztaly sablon.
   - Taroljon egy `vector<T>` taroloban jaratazonositokat.
   - Taroljon egy `vector<int>` taroloban az egyes jaratokhoz tartozo osszesitett kesesi perceket.
   - Legyen `getIndexOfRoute`, `addDelay`, es `getTotalDelay` metodusa.
   - Az `addDelay` ket parametert kapjon: egy azonosito es egy pozitiv egesz perc ertek, amit az
     adott jarathoz kell hozzadni. Ha a jarat meg nincs a taroloban, akkor uj elemkent kell felvenni.
     (3 pont)
2. Legyen `[]` operator, ami a megadott jarathoz tartozo osszesitett kesesi percekre ad vissza
   modosithato `int&` referenciat. Ha a jarat meg nincs a taroloban, 0-val kell beszurni. (2 pont)
3. Legyen `<<` operator, ami JSON tombkent irja ki a tartalmat. Minden elemben legyen `"route"` es
   `"minutes"` kulcs. A JSON 2 szokozonkent legyen indentalva. (2 pont)
4. Legyen az `extra.h` fajlban `loadDelays` fuggveny, ami egy fajlbol whitespace szeparalt
   `jarat perc` parokat olvas, es egy `DelayLedger<string>` objektumban osszegzi a keseseket.
   (3 pont)
