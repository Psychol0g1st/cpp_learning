TEMPLATE = app
CONFIG += console c++20
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += main.cpp

HEADERS += megoldott_feladatok.h \
    triagecounter.h \
    extra.h \
    json.hpp

DISTFILES += minta-stdout.txt
