#ifndef EXTRA_H
#define EXTRA_H

// ide johet a loadConsumption() fuggveny

#endif // EXTRA_H
