#ifndef ENERGYLEDGER_H
#define ENERGYLEDGER_H

// #include <iostream>
// #include <vector>
// #include <string>
// using namespace std;

// #include "json.hpp"
// using namespace nlohmann;

template <class T>
class EnergyLedger
{
    // ...
public:
    // ...

    // friend ostream& operator<< (ostream& os, const EnergyLedger<T>& el)
    // {
    //     // ...
    // }
};

#endif // ENERGYLEDGER_H
