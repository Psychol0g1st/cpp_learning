#ifndef DELAYLEDGER_H
#define DELAYLEDGER_H

// #include <iostream>
// #include <vector>
// #include <string>
// using namespace std;

// #include "json.hpp"
// using namespace nlohmann;

template <class T>
class DelayLedger
{
    // ...
public:
    // ...

    // friend ostream& operator<< (ostream& os, const DelayLedger<T>& dl)
    // {
    //     // ...
    // }
};

#endif // DELAYLEDGER_H
