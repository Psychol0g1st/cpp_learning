#include <iostream>
#include <fstream>
using namespace std;

#include "megoldott_feladatok.h"

#ifdef PART1
#include "energyledger.h"
#endif

#ifdef PART2
#include "energyledger.h"
#endif

#ifdef PART3
#include "energyledger.h"
#endif

#ifdef PART4
#include "energyledger.h"
#include "extra.h"
#endif

struct TesterGuard
{
    string partname;
    TesterGuard(const string& partname);
    ~TesterGuard();
};

int main()
{
    cout << "main() eleje!" << endl;

#ifdef PART1
    {
        TesterGuard tguard("PART1");
        EnergyLedger<string> el1;
        EnergyLedger<int> el2;
        el1.addReading("school", 12.5);
        el1.addReading("school", 7.5);
        el1.addReading("clinic", 9.0);
        el2.addReading(101, 3.5);
        el2.addReading(101, 1.5);
        el2.addReading(202, 4.25);
        cout << "el1 teszt:" << endl;
        cout << el1.getIndexOfMeter("school") << " ";
        cout << el1.getIndexOfMeter("library") << " ";
        cout << el1.getIndexOfMeter("clinic") << endl;
        cout << el1.getTotalConsumption("school") << " ";
        cout << el1.getTotalConsumption("library") << " ";
        cout << el1.getTotalConsumption("clinic") << endl;
        cout << "el2 teszt:" << endl;
        cout << el2.getIndexOfMeter(101) << " ";
        cout << el2.getIndexOfMeter(102) << " ";
        cout << el2.getIndexOfMeter(202) << endl;
        cout << el2.getTotalConsumption(101) << " ";
        cout << el2.getTotalConsumption(102) << " ";
        cout << el2.getTotalConsumption(202) << endl;
    }
#endif

#ifdef PART2
    {
        TesterGuard tguard("PART2");
        EnergyLedger<string> el3;
        el3["school"] = 18.5;
        el3.addReading("school", 1.5);
        el3["clinic"] = 9.25;
        cout << "Kiiras:" << endl;
        cout << el3["school"] << endl;
        cout << el3["clinic"] << endl;
        cout << el3["market"] << endl;
    }
#endif

#ifdef PART3
    {
        TesterGuard tguard("PART3");
        EnergyLedger<string> el1;
        el1.addReading("library", 10.0);
        el1.addReading("library", 4.5);
        el1.addReading("market", 6.75);
        cout << "el1 kiirasa:" << endl << el1 << endl;
    }
#endif

#ifdef PART4
    {
        TesterGuard tguard("PART4");
        {
            ofstream out("consumption1.txt");
            out << "school 5.5 school 4.5 clinic 3.0" << endl;
        }
        {
            ofstream out("consumption2.txt");
            out << "market 2.25 market 1.75 depot 8.0" << endl;
        }
        {
            EnergyLedger<string> el = loadConsumption("consumption1.txt");
            cout << "consumption1.txt teszt:" << endl;
            cout << "school -> " << el.getTotalConsumption("school") << endl;
            cout << "clinic -> " << el.getTotalConsumption("clinic") << endl;
            cout << "depot -> " << el.getTotalConsumption("depot") << endl;
        }
        {
            EnergyLedger<string> el = loadConsumption("consumption2.txt");
            cout << "consumption2.txt teszt:" << endl;
            cout << "market -> " << el.getTotalConsumption("market") << endl;
            cout << "depot -> " << el.getTotalConsumption("depot") << endl;
            cout << "school -> " << el.getTotalConsumption("school") << endl;
        }
    }
#endif

    cout << "main() vege!" << endl;
    return 0;
}

TesterGuard::TesterGuard(const string& p):
    partname(p)
{
    cout << endl << "----START OF " << partname << "----" << endl << endl;
}

TesterGuard::~TesterGuard()
{
    cout << endl << "----END OF " << partname << "----" << endl << endl;
}
