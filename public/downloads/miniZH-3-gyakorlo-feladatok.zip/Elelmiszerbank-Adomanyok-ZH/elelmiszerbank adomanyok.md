Elelmiszerbank Adomanyok KisZH

## 1 / 2

# FONTOS INFOK

- A feladat soran alkalmazd a megtanult objektum-orientaltsagi elveket, figyelj a konstansok es
  referenciak megfelelo hasznalatara.
- A megadott peldakodon ne modosits, hacsak a feladat nem keri.
- Figyelj a kiiras pontos formatumara, szokozokre es sortoresekre.
- Minden pont ertekelesehez szukseges, hogy az adott reszhez tartozo define szerepeljen a
  `megoldott_feladatok.h` fajlban.
- A header fajlokban csak a header guard-on belulre dolgozz.
- Peldakimenet a `main.cpp`-ben es a `minta-stdout.txt` fajlban talalhato.

Elelmiszerbank Adomanyok KisZH

## 2 / 2

# Feladat - Elelmiszerbank Adomanyok KisZH

Egy elelmiszerbanki atveteli rendszerhez kell sablon osztalyt kesziteni, amely tetszoleges `T`
tipusu adomanykategoriakhoz tudja osszesiteni az atvett darabszamot. Minden a `donationledger.h`
fajlba keruljon, `donationledger.cpp` ne legyen. Az Nlohmann JSON konyvtar a `json.hpp` fajlban adott.

Az elso feladat kotelezo, a 2-4. feladatok egymastol fuggetlenul megoldhatok.

1. Legyen egy `DonationLedger` osztaly sablon.
   - Taroljon egy `vector<T>` taroloban kategoriakat.
   - Taroljon egy `vector<int>` taroloban a kategoriakhoz tartozo osszesitett darabszamot.
   - Legyen `getIndexOfCategory`, `addDonation`, es `getDonationCount` metodusa.
   - Az `addDonation` ket parametert kapjon: egy kategoriat es egy pozitiv egesz darabszamot, amit
     a megfelelo kategoriara kell hozzaadni. Ha a kategoria meg nincs a taroloban, uj elemkent kell
     felvenni. (3 pont)
2. Legyen `[]` operator, ami a megadott kategoriara egy modosithato `int&` referenciat ad vissza.
   Ha a kategoria meg nincs a taroloban, 0-val kell beszurni. (2 pont)
3. Legyen `<<` operator, ami JSON tombkent irja ki a tartalmat. Minden elemben legyen `"category"`
   es `"items"` kulcs. A JSON 2 szokozonkent legyen indentalva. (2 pont)
4. Legyen az `extra.h` fajlban `loadDonations` fuggveny, ami whitespace szeparalt `kategoria darab`
   parokat olvas egy fajlbol, es `DonationLedger<string>` objektumban osszegzi a mennyisegeket.
   (3 pont)
