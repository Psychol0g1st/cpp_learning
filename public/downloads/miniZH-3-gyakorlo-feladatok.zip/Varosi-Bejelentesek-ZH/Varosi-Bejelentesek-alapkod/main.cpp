#include <iostream>
#include <fstream>
using namespace std;

#include "megoldott_feladatok.h"

#ifdef PART1
#include "issuecounter.h"
#endif

#ifdef PART2
#include "issuecounter.h"
#endif

#ifdef PART3
#include "issuecounter.h"
#endif

#ifdef PART4
#include "issuecounter.h"
#include "extra.h"
#endif

struct TesterGuard
{
    string partname;
    TesterGuard(const string& partname);
    ~TesterGuard();
};

int main()
{
    cout << "main() eleje!" << endl;

#ifdef PART1
    {
        TesterGuard tguard("PART1");
        IssueCounter<string> ic1;
        IssueCounter<int> ic2;
        ic1.addIssue("pothole");
        ic1.addIssue("pothole");
        ic1.addIssue("lighting");
        ic1.addIssue("graffiti");
        ic1.addIssue("graffiti");
        ic2.addIssue(11);
        ic2.addIssue(11);
        ic2.addIssue(13);
        cout << "ic1 teszt:" << endl;
        cout << ic1.getIndexOfIssue("pothole") << " ";
        cout << ic1.getIndexOfIssue("parking") << " ";
        cout << ic1.getIndexOfIssue("graffiti") << endl;
        cout << ic1.getIssueCount("pothole") << " ";
        cout << ic1.getIssueCount("parking") << " ";
        cout << ic1.getIssueCount("graffiti") << endl;
        cout << "ic2 teszt:" << endl;
        cout << ic2.getIndexOfIssue(11) << " ";
        cout << ic2.getIndexOfIssue(12) << " ";
        cout << ic2.getIndexOfIssue(13) << endl;
        cout << ic2.getIssueCount(11) << " ";
        cout << ic2.getIssueCount(12) << " ";
        cout << ic2.getIssueCount(13) << endl;
    }
#endif

#ifdef PART2
    {
        TesterGuard tguard("PART2");
        IssueCounter<string> ic3;
        ic3["pothole"] = 7;
        ic3.addIssue("pothole");
        ic3["lighting"] = 3;
        cout << "Kiiras:" << endl;
        cout << ic3["pothole"] << endl;
        cout << ic3["lighting"] << endl;
        cout << ic3["drainage"] << endl;
    }
#endif

#ifdef PART3
    {
        TesterGuard tguard("PART3");
        IssueCounter<string> ic1;
        ic1.addIssue("noise");
        ic1.addIssue("noise");
        ic1.addIssue("noise");
        ic1.addIssue("noise");
        ic1.addIssue("trash");
        ic1.addIssue("trash");
        cout << "ic1 kiirasa:" << endl << ic1 << endl;
    }
#endif

#ifdef PART4
    {
        TesterGuard tguard("PART4");
        {
            ofstream out("issues1.txt");
            out << "pothole lighting pothole graffiti pothole" << endl;
        }
        {
            ofstream out("issues2.txt");
            out << "trash trash noise drainage noise noise" << endl;
        }
        {
            IssueCounter<string> ic = getIssueFrequency("issues1.txt");
            cout << "issues1.txt teszt:" << endl;
            cout << "pothole -> " << ic.getIssueCount("pothole") << endl;
            cout << "lighting -> " << ic.getIssueCount("lighting") << endl;
            cout << "noise -> " << ic.getIssueCount("noise") << endl;
        }
        {
            IssueCounter<string> ic = getIssueFrequency("issues2.txt");
            cout << "issues2.txt teszt:" << endl;
            cout << "trash -> " << ic.getIssueCount("trash") << endl;
            cout << "noise -> " << ic.getIssueCount("noise") << endl;
            cout << "graffiti -> " << ic.getIssueCount("graffiti") << endl;
        }
    }
#endif

    cout << "main() vege!" << endl;
    return 0;
}

TesterGuard::TesterGuard(const string& p):
    partname(p)
{
    cout << endl << "----START OF " << partname << "----" << endl << endl;
}

TesterGuard::~TesterGuard()
{
    cout << endl << "----END OF " << partname << "----" << endl << endl;
}
