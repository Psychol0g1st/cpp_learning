Varosi Bejelentesek KisZH

## 1 / 2

# FONTOS INFOK

- A feladat soran alkalmazd a megtanult objektum-orientaltsagi elveket, figyelj a konstansok es
  referenciak megfelelo hasznalatara.
- A megadott peldakodon ne modosits, hacsak a feladat nem keri.
- Figyelj a kiiras pontos formatumara, szokozokre es sortoresekre.
- Minden pont ertekelesehez szukseges, hogy az adott reszhez tartozo define szerepeljen a
  `megoldott_feladatok.h` fajlban.
- A header fajlokban csak a header guard-on belulre dolgozz.
- Peldakimenet a `main.cpp`-ben es a `minta-stdout.txt` fajlban talalhato.

Varosi Bejelentesek KisZH

## 2 / 2

# Feladat - Varosi Bejelentesek KisZH

Egy onkormanyzati hibabejelento rendszerhez kell sablon osztalyt kesziteni, amely tetszoleges,
`T` tipusu hibatipusokhoz kepes bejelentesszamot tarolni. Minden a `issuecounter.h` fajlba
keruljon, `issuecounter.cpp` ne legyen. Az Nlohmann JSON konyvtar a `json.hpp` fajlban adott.

Az elso feladat kotelezo, a 2-4. feladatok egymastol fuggetlenul megoldhatok.

1. Legyen egy `IssueCounter` osztaly sablon, amely egy `vector<T>` taroloban hibatipusokat, egy
   `vector<int>` taroloban pedig a hozzajuk tartozo bejelentesszamokat tarolja.
   - Legyen `getIndexOfIssue` metodus, ami megadja az adott hibatipus indexet, vagy `-1`-et, ha
     nincs ilyen eltárolva.
   - Legyen `addIssue` metodus, ami 1-gyel noveli a megadott hibatipushoz tartozo darabszamot,
     vagy uj elemet szur be 1-es kezdoertekkel.
   - Legyen `getIssueCount` metodus, ami visszaadja a hibatipushoz tartozo darabszamot, illetve 0-t,
     ha nincs ilyen elem. (3 pont)
2. Legyen `[]` operator, ami egy `T` ertekhez tartozo darabszamra ad vissza modosithato `int&`
   referenciat. Ha nincs ilyen hibatipus, akkor 0-s kezdoertekkel kell beszurni. (2 pont)
3. Legyen `<<` operator, ami a tartalmat JSON tombkent irja ki. Minden objektumban legyen `"count"`
   es `"issue"` kulcs. A JSON 2 szokozonkent legyen indentalva. (2 pont)
4. Legyen az `extra.h` fajlban `getIssueFrequency` fuggveny, ami parameterben egy fajlnevet kap,
   es `IssueCounter<string>` taroloban visszaadja, hogy a whitespace szeparalt hibakodok hanyszor
   fordulnak elo a fajlban. (3 pont)
