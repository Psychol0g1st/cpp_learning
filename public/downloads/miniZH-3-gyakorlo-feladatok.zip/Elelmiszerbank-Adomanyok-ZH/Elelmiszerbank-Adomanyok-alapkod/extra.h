#ifndef EXTRA_H
#define EXTRA_H

// ide johet a loadDonations() fuggveny

#endif // EXTRA_H
