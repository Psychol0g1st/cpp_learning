#ifndef MEGOLDOTT_FELADATOK_H
#define MEGOLDOTT_FELADATOK_H

//#define PART1 // EnergyLedger alap (3 pont)
//#define PART2 // EnergyLedger, operator[] (2 pont)
//#define PART3 // EnergyLedger: JSON kiiras, operator<< (2 pont)
//#define PART4 // extra.h, loadConsumption() (3 pont)

#endif // MEGOLDOTT_FELADATOK_H
