#include <iostream>
#include <fstream>
using namespace std;

#include "megoldott_feladatok.h"

#ifdef PART1
#include "delayledger.h"
#endif

#ifdef PART2
#include "delayledger.h"
#endif

#ifdef PART3
#include "delayledger.h"
#endif

#ifdef PART4
#include "delayledger.h"
#include "extra.h"
#endif

struct TesterGuard
{
    string partname;
    TesterGuard(const string& partname);
    ~TesterGuard();
};

int main()
{
    cout << "main() eleje!" << endl;

#ifdef PART1
    {
        TesterGuard tguard("PART1");
        DelayLedger<string> dl1;
        DelayLedger<int> dl2;
        dl1.addDelay("M3", 4);
        dl1.addDelay("M3", 6);
        dl1.addDelay("4-6", 3);
        dl2.addDelay(5, 7);
        dl2.addDelay(7, 2);
        cout << "dl1 teszt:" << endl;
        cout << dl1.getIndexOfRoute("M3") << " ";
        cout << dl1.getIndexOfRoute("M2") << " ";
        cout << dl1.getIndexOfRoute("4-6") << endl;
        cout << dl1.getTotalDelay("M3") << " ";
        cout << dl1.getTotalDelay("M2") << " ";
        cout << dl1.getTotalDelay("4-6") << endl;
        cout << "dl2 teszt:" << endl;
        cout << dl2.getIndexOfRoute(5) << " ";
        cout << dl2.getIndexOfRoute(6) << " ";
        cout << dl2.getIndexOfRoute(7) << endl;
        cout << dl2.getTotalDelay(5) << " ";
        cout << dl2.getTotalDelay(6) << " ";
        cout << dl2.getTotalDelay(7) << endl;
    }
#endif

#ifdef PART2
    {
        TesterGuard tguard("PART2");
        DelayLedger<string> dl3;
        dl3["M2"] = 12;
        dl3.addDelay("M2", 5);
        dl3["105"] = 8;
        cout << "Kiiras:" << endl;
        cout << dl3["M2"] << endl;
        cout << dl3["105"] << endl;
        cout << dl3["7E"] << endl;
    }
#endif

#ifdef PART3
    {
        TesterGuard tguard("PART3");
        DelayLedger<string> dl1;
        dl1.addDelay("M1", 4);
        dl1.addDelay("M1", 5);
        dl1.addDelay("47", 2);
        dl1.addDelay("47", 3);
        cout << "dl1 kiirasa:" << endl << dl1 << endl;
    }
#endif

#ifdef PART4
    {
        TesterGuard tguard("PART4");
        {
            ofstream out("delays1.txt");
            out << "M3 4 M3 2 4-6 5" << endl;
        }
        {
            ofstream out("delays2.txt");
            out << "105 3 105 7 M2 1" << endl;
        }
        {
            DelayLedger<string> dl = loadDelays("delays1.txt");
            cout << "delays1.txt teszt:" << endl;
            cout << "M3 -> " << dl.getTotalDelay("M3") << endl;
            cout << "4-6 -> " << dl.getTotalDelay("4-6") << endl;
            cout << "M2 -> " << dl.getTotalDelay("M2") << endl;
        }
        {
            DelayLedger<string> dl = loadDelays("delays2.txt");
            cout << "delays2.txt teszt:" << endl;
            cout << "105 -> " << dl.getTotalDelay("105") << endl;
            cout << "M2 -> " << dl.getTotalDelay("M2") << endl;
            cout << "M4 -> " << dl.getTotalDelay("M4") << endl;
        }
    }
#endif

    cout << "main() vege!" << endl;
    return 0;
}

TesterGuard::TesterGuard(const string& p):
    partname(p)
{
    cout << endl << "----START OF " << partname << "----" << endl << endl;
}

TesterGuard::~TesterGuard()
{
    cout << endl << "----END OF " << partname << "----" << endl << endl;
}
