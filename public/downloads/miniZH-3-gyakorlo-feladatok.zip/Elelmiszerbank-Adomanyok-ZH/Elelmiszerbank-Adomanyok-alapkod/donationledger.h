#ifndef DONATIONLEDGER_H
#define DONATIONLEDGER_H

// #include <iostream>
// #include <vector>
// #include <string>
// using namespace std;

// #include "json.hpp"
// using namespace nlohmann;

template <class T>
class DonationLedger
{
    // ...
public:
    // ...

    // friend ostream& operator<< (ostream& os, const DonationLedger<T>& dl)
    // {
    //     // ...
    // }
};

#endif // DONATIONLEDGER_H
