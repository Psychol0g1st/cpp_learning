#ifndef EXTRA_H
#define EXTRA_H

// ide johet a getIssueFrequency() fuggveny

#endif // EXTRA_H
