Energetikai Meresek KisZH

## 1 / 2

# FONTOS INFOK

- A feladat soran alkalmazd a megtanult objektum-orientaltsagi elveket, figyelj a konstansok es
  referenciak megfelelo hasznalatara.
- A megadott peldakodon ne modosits, hacsak a feladat nem keri.
- Figyelj a kiiras pontos formatumara, szokozokre es sortoresekre.
- Minden pont ertekelesehez szukseges, hogy az adott reszhez tartozo define szerepeljen a
  `megoldott_feladatok.h` fajlban.
- A header fajlokban csak a header guard-on belulre dolgozz.
- Peldakimenet a `main.cpp`-ben es a `minta-stdout.txt` fajlban talalhato.

Energetikai Meresek KisZH

## 2 / 2

# Feladat - Energetikai Meresek KisZH

Egy intezmenyi energiafigyelo rendszerhez kell sablon osztalyt kesziteni, amely tetszoleges
`T` tipusu meroazonositokhoz osszesitett fogyasztasi adatot tarol. Minden a `energyledger.h`
fajlba keruljon, `energyledger.cpp` ne legyen. Az Nlohmann JSON konyvtar a `json.hpp` fajlban adott.

Az elso feladat kotelezo, a 2-4. feladatok egymastol fuggetlenul megoldhatok.

1. Legyen egy `EnergyLedger` osztaly sablon.
   - Taroljon egy `vector<T>` taroloban meroazonositokat.
   - Taroljon egy `vector<double>` taroloban az egyes merokhoz tartozo osszesitett fogyasztast.
   - Legyen `getIndexOfMeter`, `addReading`, es `getTotalConsumption` metodusa.
   - Az `addReading` ket parametert kapjon: egy azonosito es egy `double` fogyasztasi erteket, amit az
     adott merohoz kell hozzadni. Ha a mero meg nincs eltárolva, uj elemkent kell felvenni. (3 pont)
2. Legyen `[]` operator, ami a megadott merohoz tartozo osszesitett fogyasztasra ad vissza
   modosithato `double&` referenciat. Ha a mero meg nincs a taroloban, 0.0-val kell beszurni.
   (2 pont)
3. Legyen `<<` operator, ami JSON tombkent irja ki a tartalmat. Minden elemben legyen `"meter"` es
   `"kwh"` kulcs. A JSON 2 szokozonkent legyen indentalva. (2 pont)
4. Legyen az `extra.h` fajlban `loadConsumption` fuggveny, ami whitespace szeparalt `mero ertek`
   parokat olvas egy fajlbol, es `EnergyLedger<string>` objektumban osszegzi a fogyasztasi adatokat.
   (3 pont)
