#ifndef ISSUECOUNTER_H
#define ISSUECOUNTER_H

// #include <iostream>
// #include <vector>
// #include <string>
// using namespace std;

// #include "json.hpp"
// using namespace nlohmann;

template <class T>
class IssueCounter
{
    // ...
public:
    // ...

    // friend ostream& operator<< (ostream& os, const IssueCounter<T>& ic)
    // {
    //     // ...
    // }
};

#endif // ISSUECOUNTER_H
