#ifndef MEGOLDOTT_FELADATOK_H
#define MEGOLDOTT_FELADATOK_H

//#define PART1 // TriageCounter alap (3 pont)
//#define PART2 // TriageCounter, operator[] (2 pont)
//#define PART3 // TriageCounter: JSON kiiras, operator<< (2 pont)
//#define PART4 // extra.h, getWardFrequency() (3 pont)

#endif // MEGOLDOTT_FELADATOK_H
