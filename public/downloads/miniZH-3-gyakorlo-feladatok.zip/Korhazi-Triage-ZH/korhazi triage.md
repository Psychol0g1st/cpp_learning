Korhazi Triage KisZH

## 1 / 2

# FONTOS INFOK

- A feladat soran alkalmazd a megtanult objektum-orientaltsagi elveket, figyelj a konstansok es
  referenciak megfelelo hasznalatara.
- A megadott peldakodon ne modosits, hacsak a feladat nem keri. A megoldasnak ugyanezekkel a
  fajlokkal kell mukodnie.
- Figyelj a kiiras megfelelo formatumara, szokozokre, sortoresekre.
- Ugyelj arra, hogy minden lefoglalt memoria keruljon megfeleloen felszabaditasra.
- Minden pont ertekelesehez szukseges, hogy az adott ponthoz tartozo define szerepeljen a
  `megoldott_feladatok.h` header fajlban.
- A header fajlokban csak a header guard-on belulre dolgozz.
- Csak olyan kodot adj le, ami nalad is lefordul.
- A fajlokat nem tomoritve kell beadni, hanem onmagukban.
- Figyelj ra, hogy a fajlnevek pontosan azok legyenek, amiket a feladat ker.
- Peldakimenet a `main.cpp`-ben kommentben, illetve egy kulon `minta-stdout.txt` fajlban talalhato.

Korhazi Triage KisZH

## 2 / 2

# Feladat - Korhazi Triage KisZH

- A `#define PART<X>` direktivak az alapkodban is szereplo `megoldott_feladatok.h` fajlban
  szerepeljenek.

Egy surgossegi osztaly napi adatfeldolgozasahoz kell egy sablon alapu segedosztalyt kesziteni,
amely tetszoleges, `T` tipusu azonositohoz tud esetszamot tarolni. Az osztaly a `triagecounter.h`
fajlba keruljon, `triagecounter.cpp` ne legyen. A projekthez adott az Nlohmann JSON konyvtar a
`json.hpp` fajl formajaban.

Az elso feladat kotelezo, a 2-4. feladatok egymastol fuggetlenul megoldhatok.

1. Legyen egy `TriageCounter` osztaly sablon, aminek egyetlen sablonparametere egy `T` tipus, es
   az alabbi funkcionalitassal rendelkezik.
   - Tarol egy kezdetben ures `vector<T>` taroloban `T` tipusu cimkeket.
   - Tarol egy `vector<int>` taroloban a cimkekhez tartozo esetszamokat. Az egyik taroloban az
     `i`-edik cimkehez a masik taroloban az `i`-edik esetszam tartozik.
   - Konstruktor nem kell.
   - Legyen egy `getIndexOfTag` metodus, ami parameterben egy `T` erteket kap, es visszaadja az
     indexet (`int`), ahol az adott cimke el van tarolva. Ha nincs eltarolva, akkor `-1` a
     visszateresi ertek.
   - Legyen egy `addCase` metodus, ami parameterben egy `T` erteket kap, es 1-gyel noveli a hozza
     tartozo esetszamot. Ha nincs eltarolva, akkor a tarolo vegere kell szurni, kezdoertekkent 1-gyel.
   - Legyen egy `getCaseCount` metodus, ami parameterben egy `T` erteket kap, es visszaadja a hozza
     tartozo esetszamot (`int`). Ha nincs eltarolva, akkor 0-t kell visszaadni. (3 pont)
2. Legyen a `TriageCounter` osztalyban `[]` operator, ami parameterben egy `T` erteket kap, es egy
   modosithato referenciaval (`int&`) ter vissza a hozza tartozo esetszamra. Ha nincs eltarolva az
   adott cimke, akkor eloszor be kell szurni, az esetszam pedig 0-rol induljon. (2 pont)
3. Legyen a `TriageCounter` osztalyhoz `<<` operator, amellyel tetszoleges kimeneti folyamra
   kiirhato a tartalma. A kiiras formatuma egy JSON tomb legyen, minden elemben legyen `"cases"`
   es `"tag"` kulcs. A JSON 2 szokozonkent legyen indentalva. (2 pont)
4. Legyen az `extra.h` fajlban egy `getWardFrequency` fuggveny, ami parameterben egy fajlnevet kap,
   es egy `TriageCounter<string>` taroloban visszaadja, hogy az allomanyban szereplo korhazi osztaly-
   kodok hanyszor fordulnak elo. A fajl whitespace szeparalt tokeneket tartalmaz, peldaul `ICU`,
   `LAB`, `SURG`. (3 pont)
