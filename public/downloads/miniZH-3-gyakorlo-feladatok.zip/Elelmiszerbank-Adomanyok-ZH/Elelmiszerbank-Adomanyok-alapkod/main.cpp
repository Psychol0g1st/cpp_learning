#include <iostream>
#include <fstream>
using namespace std;

#include "megoldott_feladatok.h"

#ifdef PART1
#include "donationledger.h"
#endif

#ifdef PART2
#include "donationledger.h"
#endif

#ifdef PART3
#include "donationledger.h"
#endif

#ifdef PART4
#include "donationledger.h"
#include "extra.h"
#endif

struct TesterGuard
{
    string partname;
    TesterGuard(const string& partname);
    ~TesterGuard();
};

int main()
{
    cout << "main() eleje!" << endl;

#ifdef PART1
    {
        TesterGuard tguard("PART1");
        DonationLedger<string> dl1;
        DonationLedger<int> dl2;
        dl1.addDonation("rice", 12);
        dl1.addDonation("rice", 8);
        dl1.addDonation("beans", 5);
        dl2.addDonation(101, 3);
        dl2.addDonation(101, 2);
        dl2.addDonation(202, 7);
        cout << "dl1 teszt:" << endl;
        cout << dl1.getIndexOfCategory("rice") << " ";
        cout << dl1.getIndexOfCategory("oil") << " ";
        cout << dl1.getIndexOfCategory("beans") << endl;
        cout << dl1.getDonationCount("rice") << " ";
        cout << dl1.getDonationCount("oil") << " ";
        cout << dl1.getDonationCount("beans") << endl;
        cout << "dl2 teszt:" << endl;
        cout << dl2.getIndexOfCategory(101) << " ";
        cout << dl2.getIndexOfCategory(102) << " ";
        cout << dl2.getIndexOfCategory(202) << endl;
        cout << dl2.getDonationCount(101) << " ";
        cout << dl2.getDonationCount(102) << " ";
        cout << dl2.getDonationCount(202) << endl;
    }
#endif

#ifdef PART2
    {
        TesterGuard tguard("PART2");
        DonationLedger<string> dl3;
        dl3["pasta"] = 14;
        dl3.addDonation("pasta", 6);
        dl3["milk"] = 9;
        cout << "Kiiras:" << endl;
        cout << dl3["pasta"] << endl;
        cout << dl3["milk"] << endl;
        cout << dl3["fruit"] << endl;
    }
#endif

#ifdef PART3
    {
        TesterGuard tguard("PART3");
        DonationLedger<string> dl1;
        dl1.addDonation("canned_soup", 11);
        dl1.addDonation("canned_soup", 4);
        dl1.addDonation("flour", 7);
        cout << "dl1 kiirasa:" << endl << dl1 << endl;
    }
#endif

#ifdef PART4
    {
        TesterGuard tguard("PART4");
        {
            ofstream out("donations1.txt");
            out << "rice 10 rice 5 beans 3" << endl;
        }
        {
            ofstream out("donations2.txt");
            out << "milk 8 flour 6 milk 4" << endl;
        }
        {
            DonationLedger<string> dl = loadDonations("donations1.txt");
            cout << "donations1.txt teszt:" << endl;
            cout << "rice -> " << dl.getDonationCount("rice") << endl;
            cout << "beans -> " << dl.getDonationCount("beans") << endl;
            cout << "milk -> " << dl.getDonationCount("milk") << endl;
        }
        {
            DonationLedger<string> dl = loadDonations("donations2.txt");
            cout << "donations2.txt teszt:" << endl;
            cout << "milk -> " << dl.getDonationCount("milk") << endl;
            cout << "flour -> " << dl.getDonationCount("flour") << endl;
            cout << "rice -> " << dl.getDonationCount("rice") << endl;
        }
    }
#endif

    cout << "main() vege!" << endl;
    return 0;
}

TesterGuard::TesterGuard(const string& p):
    partname(p)
{
    cout << endl << "----START OF " << partname << "----" << endl << endl;
}

TesterGuard::~TesterGuard()
{
    cout << endl << "----END OF " << partname << "----" << endl << endl;
}
