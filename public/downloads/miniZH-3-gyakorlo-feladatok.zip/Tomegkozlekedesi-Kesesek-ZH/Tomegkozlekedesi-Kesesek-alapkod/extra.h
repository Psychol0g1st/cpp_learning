#ifndef EXTRA_H
#define EXTRA_H

// ide johet a loadDelays() fuggveny

#endif // EXTRA_H
