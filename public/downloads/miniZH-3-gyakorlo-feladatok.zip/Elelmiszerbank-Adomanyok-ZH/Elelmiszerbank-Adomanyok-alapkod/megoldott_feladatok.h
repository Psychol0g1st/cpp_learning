#ifndef MEGOLDOTT_FELADATOK_H
#define MEGOLDOTT_FELADATOK_H

//#define PART1 // DonationLedger alap (3 pont)
//#define PART2 // DonationLedger, operator[] (2 pont)
//#define PART3 // DonationLedger: JSON kiiras, operator<< (2 pont)
//#define PART4 // extra.h, loadDonations() (3 pont)

#endif // MEGOLDOTT_FELADATOK_H
