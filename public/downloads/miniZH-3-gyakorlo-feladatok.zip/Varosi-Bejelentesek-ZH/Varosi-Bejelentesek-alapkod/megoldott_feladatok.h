#ifndef MEGOLDOTT_FELADATOK_H
#define MEGOLDOTT_FELADATOK_H

//#define PART1 // IssueCounter alap (3 pont)
//#define PART2 // IssueCounter, operator[] (2 pont)
//#define PART3 // IssueCounter: JSON kiiras, operator<< (2 pont)
//#define PART4 // extra.h, getIssueFrequency() (3 pont)

#endif // MEGOLDOTT_FELADATOK_H
