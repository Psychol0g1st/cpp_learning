#ifndef TRIAGECOUNTER_H
#define TRIAGECOUNTER_H

// #include <iostream>
// #include <vector>
// #include <string>
// using namespace std;

// #include "json.hpp"
// using namespace nlohmann;

template <class T>
class TriageCounter
{
    // ...
public:
    // ...

    // friend ostream& operator<< (ostream& os, const TriageCounter<T>& tc)
    // {
    //     // ...
    // }
};

#endif // TRIAGECOUNTER_H
